<template>
  <div class="space-y-6 max-w-2xl">
    <header>
      <h1 class="text-2xl font-bold tracking-tight">设置</h1>
      <p class="text-sm text-muted-foreground mt-1">账号信息与衣橱数据概览</p>
    </header>

    <!-- 账号信息 -->
    <UiCard>
      <div class="p-6 space-y-4">
        <h2 class="text-sm font-semibold">账号信息</h2>
        <div v-if="userLoading" class="text-sm text-muted-foreground">加载中...</div>
        <div v-else-if="user" class="grid gap-3 text-sm">
          <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-accent flex items-center justify-center text-lg font-semibold">
              {{ (user.display_name || user.email || '?').charAt(0).toUpperCase() }}
            </div>
            <div>
              <div class="font-medium">{{ user.display_name || '未设置名称' }}</div>
              <div class="text-xs text-muted-foreground">{{ user.email }}</div>
            </div>
          </div>
          <div class="grid gap-2 pt-2 border-t">
            <div class="flex justify-between border-b py-2">
              <span class="text-muted-foreground">用户 ID</span>
              <span class="font-mono text-xs">{{ user.id.slice(0, 8) }}...</span>
            </div>
            <div class="flex justify-between border-b py-2">
              <span class="text-muted-foreground">注册时间</span>
              <span>{{ formatDate(user.created_at) }}</span>
            </div>
            <div class="flex justify-between py-2">
              <span class="text-muted-foreground">引导完成</span>
              <span>{{ user.onboarding_completed ? '✓ 已完成' : '未完成' }}</span>
            </div>
          </div>
        </div>
      </div>
    </UiCard>

    <!-- 数据概览 -->
    <UiCard>
      <div class="p-6 space-y-4">
        <h2 class="text-sm font-semibold">数据概览</h2>
        <div v-if="statsLoading" class="text-sm text-muted-foreground">加载中...</div>
        <div v-else class="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div class="rounded-lg bg-accent/40 p-4 text-center">
            <div class="text-2xl font-bold">{{ stats.total }}</div>
            <div class="text-xs text-muted-foreground mt-1">衣物总数</div>
          </div>
          <div class="rounded-lg bg-accent/40 p-4 text-center">
            <div class="text-2xl font-bold">{{ stats.favorites }}</div>
            <div class="text-xs text-muted-foreground mt-1">已收藏</div>
          </div>
          <div class="rounded-lg bg-accent/40 p-4 text-center">
            <div class="text-2xl font-bold">{{ stats.needsWash }}</div>
            <div class="text-xs text-muted-foreground mt-1">待清洗</div>
          </div>
          <div class="rounded-lg bg-accent/40 p-4 text-center">
            <div class="text-2xl font-bold">{{ stats.wardrobes }}</div>
            <div class="text-xs text-muted-foreground mt-1">衣橱数量</div>
          </div>
        </div>
      </div>
    </UiCard>

    <!-- 快捷入口 -->
    <UiCard>
      <div class="p-6 space-y-3">
        <h2 class="text-sm font-semibold">快捷入口</h2>
        <div class="grid gap-2">
          <RouterLink to="/items/new" class="flex items-center justify-between rounded-md border p-3 hover:bg-accent/30 transition-colors text-sm">
            <span>录入新衣物</span><span class="text-muted-foreground">→</span>
          </RouterLink>
          <RouterLink to="/fitting" class="flex items-center justify-between rounded-md border p-3 hover:bg-accent/30 transition-colors text-sm">
            <span>前往试衣间</span><span class="text-muted-foreground">→</span>
          </RouterLink>
          <RouterLink to="/wardrobes" class="flex items-center justify-between rounded-md border p-3 hover:bg-accent/30 transition-colors text-sm">
            <span>管理衣橱</span><span class="text-muted-foreground">→</span>
          </RouterLink>
          <RouterLink to="/taxonomy" class="flex items-center justify-between rounded-md border p-3 hover:bg-accent/30 transition-colors text-sm">
            <span>初始化分类标签</span><span class="text-muted-foreground">→</span>
          </RouterLink>
        </div>
      </div>
    </UiCard>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { api } from '@/lib/api'
import { listItems } from '@/lib/itemsApi'
import { listWardrobes } from '@/lib/wardrobesApi'
import UiCard from '@/components/ui/UiCard.vue'

interface UserMe {
  id: string
  email: string
  display_name: string | null
  avatar_url: string | null
  onboarding_completed: boolean
  created_at: string
  updated_at: string
}

const user = ref<UserMe | null>(null)
const userLoading = ref(false)
const statsLoading = ref(false)
const stats = ref({ total: 0, favorites: 0, needsWash: 0, wardrobes: 0 })

function formatDate(ts: string) {
  if (!ts) return ''
  return new Date(ts).toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' })
}

async function loadUser() {
  userLoading.value = true
  try {
    user.value = await api.get<UserMe>('/users/me')
  } catch { /* ignore */ } finally {
    userLoading.value = false
  }
}

async function loadStats() {
  statsLoading.value = true
  try {
    const [all, fav, wash, wards] = await Promise.all([
      listItems({ page_size: 1 }),
      listItems({ favorite: true, page_size: 1 }),
      listItems({ needs_wash: true, page_size: 1 }),
      listWardrobes(),
    ])
    stats.value = {
      total: all.total,
      favorites: fav.total,
      needsWash: wash.total,
      wardrobes: wards.length,
    }
  } catch { /* ignore */ } finally {
    statsLoading.value = false
  }
}

onMounted(() => {
  loadUser()
  loadStats()
})
</script>

<style scoped></style>
